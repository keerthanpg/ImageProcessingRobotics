#include "stdafx.h"
#include <stdio.h>
#include <highgui.h>
#include <cv.h>
#include <cxcore.h>

 #define IMGDATA(image,i,j,k) (((uchar*)image->imageData)[(i)*(image->widthStep) + (j)*(image->nChannels) + (k)])	//extracts pixel information
long int a[256];
IplImage* get_histogram(IplImage*gscale)
{
	IplImage *hist;
	hist=cvCreateImage(cvSize(256,600),IPL_DEPTH_8U,1);
		for(int i=0;i<=255;i++)
	{
		for(int j=600-1;j>=0;j--)
		{
			if(j<(600-a[i]/10))
				IMGDATA(hist,j,i,0)=255;
			else
				IMGDATA(hist,j,i,0)=0;
		}
	}
	return hist;
}




IplImage* get_binary(IplImage* img, int thresh){

	IplImage* bin; //To store and return the result
	int i,j,ht,wd;
	ht = img->height; wd = img->width; 
	bin = cvCreateImage(cvSize(wd,ht),IPL_DEPTH_8U,1);

	for(i=0;i<ht;i++)
	{
		for(j=0;j<wd;j++)
		{
		//It is checked if the gray-scale equivalent is larger than the threshold or not 
		if((0.33*(IMGDATA(img,i,j,0))+0.56*(IMGDATA(img,i,j,1))+0.11*(IMGDATA(img,i,j,2))) > thresh)
			IMGDATA(bin,i,j,0) = 255;//Assigned white
		else
			IMGDATA(bin,i,j,0) = 0;//Assigned black
		}
	}

	return bin; //Result is returned
}

int main()
{ 

CvCapture* capture=cvCreateCameraCapture(-1);
IplImage *frame, *gscale, *bin, *hist;
char *win="grayscale", *win2="binary", *win3="histogram";
frame=cvQueryFrame(capture);
gscale=cvCreateImage(cvGetSize(frame), IPL_DEPTH_8U,1);


cvNamedWindow(win,CV_WINDOW_AUTOSIZE);
cvNamedWindow(win2,CV_WINDOW_AUTOSIZE);
while(1)
{
	frame=cvQueryFrame(capture);
	cvCvtColor(frame, gscale,CV_BGR2GRAY);
	int ht=frame->height, wd=frame->width;
	for(int i=0;i<256;i++)
a[i]=0;
	for(int i=0;i<ht;i++)
	{
		for(int j=0;j<wd;j++)
		{
			int k=IMGDATA(gscale,i,j,0);
			a[k]++;
		}
	}
	int num=0;
	for(int i=0;i<256;i++)
		num+=a[i];
	int k=0, mid;
	if(num%2==0)
		mid=num/2;
	else mid=num/2+1;
	int i;	
	for(i=0;i<256;i++)
	{
		k+=a[i];
		if(k>=mid)
			break;
	}
	int median=i;
	bin=get_binary(frame,median);
	hist=get_histogram(gscale);
	cvShowImage(win3,hist);
	cvShowImage(win,gscale);
	cvShowImage(win2,bin);
	char c=cvWaitKey(55);
	if(c==27)
		break;
}
cvReleaseImage(&frame);
cvReleaseImage(&gscale);
cvReleaseImage(&bin);
cvDestroyWindow(win);
cvDestroyWindow(win2);
cvReleaseCapture(&capture);
}



	